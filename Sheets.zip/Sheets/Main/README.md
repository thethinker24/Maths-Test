# Math Worksheet Generator

This repository helps teachers generate math worksheets for students based on whatever theme they wish. The generator creates plain and pirate themed math worksheets containing 10 different levels of difficulty. You can download the files in the releases.

![plot](/advertising/Original_montage.PNG)

![plot](/advertising/pirate_ad.PNG)

![plot](/advertising/solutions_ad.PNG)

![Alt Text](/advertising/video.gif)